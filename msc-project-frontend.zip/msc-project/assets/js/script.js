// import Sortable from 'sortablejs/modular/sortable.complete.esm';
// // import Sortable, { AutoScroll } from 'sortablejs/modular/sortable.core.esm';
// // Cherrypick extra plugins
// import Sortable, { MultiDrag, Swap } from 'sortablejs';


// Default Ready Function
const Noah = function init() {
    // Forces Correct Operating Context >= ES2015

    $(() => {
        // const username = document.getElementById('username')
        // const password = document.getElementById('password')
        // const submit = document.getElementById('submit')
        // const formSection = document.getElementById('form-section')
        // submit.addEventListener('click', function validate() {
        //     if (username.value && password.value) {
        //         username.classList.add('valid');
        //         password.classList.add('valid');
        //         submit.classList.add('valid');
        //         formSection.style.opacity = '0';
        //     }
        //     if (username.value) {
        //         username.classList.remove('error');
        //     } else {
        //         username.classList.add('error');
        //     }
        //     if (password.value) {
        //         password.classList.remove('error');
        //     } else {
        //         password.classList.add('error');
        //     }
        // });


        // particlesJS("particles-js", {
        //     "particles": {
        //         "number": {
        //             "value": 50,
        //             "density": {
        //                 "enable": true,
        //                 "value_area": 700
        //             }
        //         },
        //         "color": {
        //             "value": "#00d4ff"
        //         },
        //         "shape": {
        //             "type": "circle",
        //             "stroke": {
        //                 "width": 0,
        //                 "color": "#00d4ff"
        //             },
        //             "polygon": {
        //                 "nb_sides": 5
        //             },
        //         },
        //         "opacity": {
        //             "value": 0.5,
        //             "random": false,
        //             "anim": {
        //                 "enable": false,
        //                 "speed": 1,
        //                 "opacity_min": 0.1,
        //                 "sync": false
        //             }
        //         },
        //         "size": {
        //             "value": 3,
        //             "random": true,
        //             "anim": {
        //                 "enable": false,
        //                 "speed": 40,
        //                 "size_min": 0.1,
        //                 "sync": false
        //             }
        //         },
        //         "line_linked": {
        //             "enable": true,
        //             "distance": 150,
        //             "color": "#00d4ff",
        //             "opacity": 0.4,
        //             "width": 1
        //         },
        //         "move": {
        //             "enable": true,
        //             "speed": 6,
        //             "direction": "none",
        //             "random": false,
        //             "straight": false,
        //             "out_mode": "out",
        //             "bounce": false,
        //             "attract": {
        //                 "enable": false,
        //                 "rotateX": 600,
        //                 "rotateY": 1200
        //             }
        //         }
        //     },
        //     "interactivity": {
        //         "detect_on": "canvas",
        //         "events": {
        //             "onhover": {
        //                 "enable": true,
        //                 "mode": "repulse"
        //             },
        //             "onclick": {
        //                 "enable": true,
        //                 "mode": "push"
        //             },
        //             "resize": true
        //         },
        //         "modes": {
        //             "grab": {
        //                 "distance": 140,
        //                 "line_linked": {
        //                     "opacity": 1
        //                 }
        //             },
        //             "bubble": {
        //                 "distance": 200,
        //                 "size": 40,
        //                 "duration": 5,
        //                 "opacity": 8,
        //                 "speed": 3
        //             },
        //             "repulse": {
        //                 "distance": 200,
        //                 "duration": 0.4
        //             },
        //             "push": {
        //                 "particles_nb": 4
        //             },
        //             "remove": {
        //                 "particles_nb": 2
        //             }
        //         }
        //     },
        //     "retina_detect": true
        // });



        // function dragit(ev) {
        //     shadow = ev.target;
        // }

        // function dragover(e) {
        //     const children = Array.from(e.target.parentNode.parentNode.children);
        //     if (children.indexOf(e.target.parentNode) > children.indexOf(shadow))
        //         e.target.parentNode.after(shadow);
        //     else e.target.parentNode.before(shadow);
        // }
        // /* end of draggable code from codepen */
        // dragover();
        // dragit();
    });

    const navButtons = document.querySelectorAll('.nav-button');
    const sections = document.querySelectorAll('.section');
    navButtons.forEach(navButton => {
        navButton.addEventListener('click', function activeNav() {
            document.querySelector('.active-nav').classList.remove('active-nav');
            navButton.classList.add('active-nav');
            const getId = navButton.getAttribute("id");
            sections.forEach(section => {
                const descDisplayStyle =
                    section.getAttribute("data-id") === getId ? "block" : "none";
                section.style.display = descDisplayStyle;
            });
        });
    });

    // Sortable.mount(new MultiDrag(), new Swap());


    // Cherrypick default plugins

    // Sortable.mount(new AutoScroll());

    // admin adding topics
    // $("#topics-form").submit(function addTopics(ev) {
    //     // alert("Handler for .submit() called.");
    //     ev.preventDefault();
    //     const $form = $(this);
    //     const title = $form.find("input[name='topic-title']").val();
    //     const link = $form.find("input[name='topic-link']").val();
    //     console.log(title, link);
    //     const posting = $.post('url', { title: title, link: link });

    //     // $("#theForm").ajaxForm({ url: 'server.php', type: 'post' });


    // });
    // $(document).ready(function new1() {
    //     $('#submit').click(function new2(eve) {
    //         eve.preventDefault();
    //         const title = $('#topic-title').val();
    //         const link = $('#topic-title').val();
    //         const actionTo = $('#topics-form').attr('action');
    //         $.post(actionTo, {
    //                 title: title,
    //                 body: link
    //             },
    //             function new3(data, status) {
    //                 alert("Data: " + data + "\nStatus: " + status);
    //             });

    //     });

    // });

};
Noah();